public class Program3
{
    public static void main(String args[])
    {
        double a = 2.0;
        double b = 3.0;
        double c = 4.0;
        double x = 5.0;
        double y = 6.0;
        
        double Y = a*x*x + b*y + c;
        System.out.println("The value of Y is : " + Y);
    }
}