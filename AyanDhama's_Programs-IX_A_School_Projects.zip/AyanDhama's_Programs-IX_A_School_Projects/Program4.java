public class Program4
{
    public static void main(int a, int b, int c)
    {
        double equation = b*b - 4*a*c;
        System.out.println("The value is : " + equation);
    }
}