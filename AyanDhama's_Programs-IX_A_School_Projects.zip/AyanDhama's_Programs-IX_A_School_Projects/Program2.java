import java.util.*;
public class Program2
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the address: ");
        String a = sc.nextLine();
        System.out.println("SCHOOL ADDRESS - " + a);
    }
}