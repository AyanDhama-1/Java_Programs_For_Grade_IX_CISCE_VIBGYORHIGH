public class Program1
{
    public static void main(String[] args)
    {
        System.out.println("Welcome to \"java\" class");
        System.out.println("Java is a 'High Level' || OBJECT ORIENTED");
        System.out.println("|| programming language.");
    }
}