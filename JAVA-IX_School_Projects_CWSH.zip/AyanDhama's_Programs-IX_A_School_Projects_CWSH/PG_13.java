public class PG_13
 {
   public static void main(int a)
   {
       int s = a*a;
       int c = a*a*a;
       System.out.println("Square is:" + s);
       System.out.println("Cube is:" + c);
   }
 }
