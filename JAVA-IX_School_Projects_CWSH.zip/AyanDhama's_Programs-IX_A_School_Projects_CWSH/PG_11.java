public class PG_11
 {
   public static void main(String args[])
   {
       
       System.out.println("HI!!" );
   }
 }
