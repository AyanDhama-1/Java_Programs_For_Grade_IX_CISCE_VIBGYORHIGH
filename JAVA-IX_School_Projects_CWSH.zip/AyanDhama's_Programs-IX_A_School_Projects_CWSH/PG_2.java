 public class PG_2
 {
   public static void main(String args [])
   {
       int a=10,b=20;
       double c =a+b;
       System.out.println("Sum is :"+c);
   }
 }