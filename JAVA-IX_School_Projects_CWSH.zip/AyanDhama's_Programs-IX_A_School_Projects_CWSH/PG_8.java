public class PG_8
{
    public static void main(String args[])
    {
        int a = 10;
        int b = 20;
        int c = 30;

        double avg = (a + b + c) / 3.0;

        System.out.println("Average = " + avg);
    }
}
