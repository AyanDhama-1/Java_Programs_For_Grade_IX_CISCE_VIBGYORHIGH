public class PG_4
 {
   public static void main(String args [])
   {
       String n="simran",g="IX",s="VIBGYOR";
       System.out.println("Name-" + n + " Studying in"+ s +" Grade-" + g);
   }
 }
