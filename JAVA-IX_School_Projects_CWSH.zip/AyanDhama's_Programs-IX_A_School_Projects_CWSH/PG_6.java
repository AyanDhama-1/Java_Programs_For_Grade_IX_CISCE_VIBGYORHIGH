public class PG_6
{
    public static void main(String[] args)
    {
        double number = 98.75;
        int result;

        result = (int) number;

        System.out.println("Double Value = " + number);
        System.out.println("Integer Value = " + result);
    }
}