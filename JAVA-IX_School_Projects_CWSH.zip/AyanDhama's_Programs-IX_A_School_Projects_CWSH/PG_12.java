public class PG_12
 {
   public static void main(String args[])
   {
       int r=+1;
       System.out.println("result is: "+ r);
       
       r=--r ;
       System.out.println("result is: "+ r);
       
       r=++r ;
       System.out.println("result is: "+ r);
       
       r=-r ;
       System.out.println("result is: "+ r);
       
       boolean sucess =false;
       System.out.println(sucess);
       System.out.println(!sucess);
   }
 }
