public class PG_7
{
    public static void main(int n)
    {
        

        int square = n * n;
        int cube = n * n * n;

        System.out.println("Square = " + square);
        System.out.println("Cube = " + cube);
    }
}