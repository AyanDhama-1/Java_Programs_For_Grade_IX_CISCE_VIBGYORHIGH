public class PG_3
 {
   public static void main(String args [])
   {
       int h=10,b=50;
       double a =0.5*h*b;
       System.out.println("Area is :"+a);
   }
 }