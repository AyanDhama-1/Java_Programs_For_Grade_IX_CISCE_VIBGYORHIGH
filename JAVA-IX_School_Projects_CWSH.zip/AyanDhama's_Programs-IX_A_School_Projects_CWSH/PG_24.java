public class PG_24
 {
   public static void main(String args[])
   {
       
   }
 }
