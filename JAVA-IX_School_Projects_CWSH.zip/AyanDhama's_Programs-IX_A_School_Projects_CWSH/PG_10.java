public class PG_10
 {
   public static void main(int a,int b)
   {
       int p=a*b;
       System.out.println("Product is ;" +p);
   }
 }
