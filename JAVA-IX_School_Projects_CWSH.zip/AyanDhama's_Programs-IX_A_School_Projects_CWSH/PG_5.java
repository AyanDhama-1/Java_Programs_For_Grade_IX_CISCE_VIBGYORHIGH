public class PG_5
{
    public static void main(String[] args)
    {
        int subject1 = 85;
        int subject2 = 90;
        int subject3 = 78;

        double average;

        average = (subject1 + subject2 + subject3) / 3.0;

        System.out.println("Marks in Subject 1: " + subject1);
        System.out.println("Marks in Subject 2: " + subject2);
        System.out.println("Marks in Subject 3: " + subject3);
        System.out.println("Average Marks = " + average);
    }
}