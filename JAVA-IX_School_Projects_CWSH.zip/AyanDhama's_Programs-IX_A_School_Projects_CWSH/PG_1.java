public class PG_1
 {
   public static void main(String args [])
   {
       int num=10;
       System.out.println("Number is ;" +num);
   }
 }
