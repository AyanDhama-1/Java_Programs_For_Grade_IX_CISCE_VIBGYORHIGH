public class PG10
 {
   public static void main(String args [])
   {
       
   }
 }
