public class PG_9
 {
   public static void main(String args [])
   {
       
   }
 }
