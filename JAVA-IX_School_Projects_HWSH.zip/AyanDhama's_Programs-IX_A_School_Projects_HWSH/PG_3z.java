public class PG_3z
 {
   public static void main(String args [])
   {
       
   }
 }
