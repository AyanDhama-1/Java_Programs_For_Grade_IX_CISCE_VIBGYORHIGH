public class PG_6
 {
   public static void main(String args [])
   {
       
   }
 }
