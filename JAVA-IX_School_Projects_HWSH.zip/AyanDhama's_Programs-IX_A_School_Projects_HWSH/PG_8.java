public class PG_8
 {
   public static void main(String args [])
   {
       
   }
 }
