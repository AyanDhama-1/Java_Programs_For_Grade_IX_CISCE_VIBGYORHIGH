public class PG_4
 {
   public static void main(String args [])
   {
       
   }
 }
