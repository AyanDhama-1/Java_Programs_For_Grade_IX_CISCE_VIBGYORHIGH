public class PG_1
 {
   public static void main(String args [])
   {
       
   }
 }
