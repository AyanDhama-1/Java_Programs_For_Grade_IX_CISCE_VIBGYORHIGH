import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Random;

public class FlappyBird extends JPanel implements ActionListener, KeyListener {

    int birdX = 100;
    int birdY = 250;
    int velocity = 0;
    int gravity = 1;
    int jump = -12;

    int pipeX = 500;
    int pipeWidth = 70;
    int gapHeight = 150;
    int gapY = 100;

    int score = 0;
    boolean gameOver = false;
    boolean started = false;

    Timer timer;
    Random random = new Random();

    public FlappyBird() {
        JFrame frame = new JFrame("Flappy Bird");
        frame.setSize(500, 600);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(this);
        frame.setVisible(true);
        frame.addKeyListener(this);

        timer = new Timer(20, this);
        timer.start();
    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);

        // Sky
        g.setColor(Color.CYAN);
        g.fillRect(0, 0, 500, 600);

        // Ground
        g.setColor(new Color(139,69,19));
        g.fillRect(0, 550, 500, 50);

        // Bird
        g.setColor(Color.YELLOW);
        g.fillOval(birdX, birdY, 30, 30);

        // Pipes
        g.setColor(Color.GREEN);
        g.fillRect(pipeX, 0, pipeWidth, gapY);
        g.fillRect(pipeX, gapY + gapHeight, pipeWidth,
                550 - (gapY + gapHeight));

        // Score
        g.setColor(Color.BLACK);
        g.setFont(new Font("Arial", Font.BOLD, 25));
        g.drawString("Score: " + score, 20, 40);

        if (!started) {
            g.drawString("Press SPACE to Start", 100, 250);
        }

        if (gameOver) {
            g.setFont(new Font("Arial", Font.BOLD, 30));
            g.drawString("GAME OVER", 140, 250);
            g.drawString("Press R to Restart", 90, 300);
        }
    }

    public void actionPerformed(ActionEvent e) {

        if (started && !gameOver) {

            velocity += gravity;
            birdY += velocity;

            pipeX -= 5;

            if (pipeX + pipeWidth < 0) {
                pipeX = 500;
                gapY = random.nextInt(250) + 50;
                score++;
            }

            // Ground and ceiling
            if (birdY < 0 || birdY + 30 > 550) {
                gameOver = true;
            }

            // Pipe collision
            if (birdX + 30 > pipeX &&
                birdX < pipeX + pipeWidth &&
                (birdY < gapY || birdY + 30 > gapY + gapHeight)) {
                gameOver = true;
            }
        }

        repaint();
    }

    public void keyPressed(KeyEvent e) {

        if (e.getKeyCode() == KeyEvent.VK_SPACE) {
            started = true;

            if (!gameOver) {
                velocity = jump;
            }
        }

        if (e.getKeyCode() == KeyEvent.VK_R && gameOver) {

            birdY = 250;
            velocity = 0;
            pipeX = 500;
            gapY = random.nextInt(250) + 50;
            score = 0;
            gameOver = false;
            started = false;
        }
    }

    public void keyReleased(KeyEvent e) {}

    public void keyTyped(KeyEvent e) {}

    public static void main(String[] args) {
        new FlappyBird();
    }
}